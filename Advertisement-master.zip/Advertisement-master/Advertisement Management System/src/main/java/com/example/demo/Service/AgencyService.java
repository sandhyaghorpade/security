package com.example.demo.Service;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.Agency;
import com.example.demo.model.Customer;

public interface AgencyService {

	
	
	
	
	
	
	public Agency saveAgency(Agency agency);
	
	
}
