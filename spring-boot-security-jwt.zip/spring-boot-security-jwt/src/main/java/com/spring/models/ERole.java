package com.spring.models;

public enum ERole {
	ROLE_USER,
    ROLE_EMPLOYEE,
    ROLE_ADMIN
}
